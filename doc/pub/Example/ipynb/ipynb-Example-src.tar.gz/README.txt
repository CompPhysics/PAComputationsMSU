This IPython notebook Example.ipynb does not require any additional
programs.

This IPython notebook Quantum.ipynb does not require any additional
programs.

This IPython notebook Elmag.ipynb does not require any additional
programs.

This IPython notebook StatPhys.ipynb does not require any additional
programs.

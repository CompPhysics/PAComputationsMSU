This IPython notebook Presentation.ipynb does not require any additional
programs.

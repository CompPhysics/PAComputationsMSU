This IPython notebook ExecSummary.ipynb does not require any additional
programs.

This IPython notebook survey.ipynb does not require any additional
programs.

This IPython notebook Draft.ipynb does not require any additional
programs.

This IPython notebook Messina.ipynb does not require any additional
programs.

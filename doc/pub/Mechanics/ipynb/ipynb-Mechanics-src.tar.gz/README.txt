This IPython notebook Mechanics.ipynb does not require any additional
programs.
